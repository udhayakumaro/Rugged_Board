#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define ADC_PATH "/sys/bus/iio/devices/iio\:device0/in_voltage6_raw"
#define MAX_ADC_VALUE 4095.0  
#define REF_VOLTAGE 3.3        


int read_adc() {
    FILE *fp;
    int value;

    fp = fopen(ADC_PATH, "r");
    if (fp == NULL) {
        perror("Error opening ADC file");
        return -1;
    }

    fscanf(fp, "%d", &value);
    fclose(fp);

    return value;
}

int main() {
    int raw_value;
    float voltage, moisture_percentage;

    while (1) {
        raw_value = read_adc();
        if (raw_value == -1) {
            return 1;
        }


        voltage = (raw_value / MAX_ADC_VALUE) * REF_VOLTAGE;


        moisture_percentage = (1 - (raw_value / MAX_ADC_VALUE)) * 100;


        printf("Raw ADC Value: %d | Voltage: %.2fV | Moisture: %.2f%%\n",
               raw_value, voltage, moisture_percentage);

        sleep(2);
    }

    return 0;
}

