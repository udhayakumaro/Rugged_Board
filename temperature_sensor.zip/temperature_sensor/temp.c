#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define ADC_CHANNEL_PATH "/sys/bus/iio/devices/iio:device0/in_voltage3_raw"
#define REFERENCE_VOLTAGE 3.3  // ADC reference voltage
#define MAX_ADC_VALUE 4095    // 12-bit ADC (0-4095)
#define MIN_TEMPERATURE 25.0  // Minimum temperature (°C)
#define MAX_TEMPERATURE 31.0  // Maximum temperature (°C)
#define MIN_HUMIDITY 37.0     // Minimum humidity (%)
#define MAX_HUMIDITY 45.0     // Maximum humidity (%)

int read_adc_raw(const char *channel_path) {
    FILE *file = fopen(channel_path, "r");
    if (!file) {
        perror("Error opening ADC channel file");
        exit(EXIT_FAILURE);
    }
    int raw_value;
    if (fscanf(file, "%d", &raw_value) != 1) {
        perror("Error reading ADC value");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    fclose(file);
    return raw_value;
}

float convert_to_temperature(int raw_value) {
    // Convert the raw ADC value to temperature (°C)
    return MIN_TEMPERATURE + ((float)raw_value / MAX_ADC_VALUE) * (MAX_TEMPERATURE - MIN_TEMPERATURE);
}

float convert_to_humidity(int raw_value) {
    // Convert the raw ADC value to humidity (%)
    return MIN_HUMIDITY + ((float)raw_value / MAX_ADC_VALUE) * (MAX_HUMIDITY - MIN_HUMIDITY);
}

int main() {
    printf("Reading sensor data (temperature and humidity) every 10 seconds...\n");

    while (1) {
        // Read raw ADC value
        int raw_value = read_adc_raw(ADC_CHANNEL_PATH);

        // Convert to temperature and humidity
        float temperature = convert_to_temperature(raw_value);
        float humidity = convert_to_humidity(raw_value);

        // Print the results
        printf("Raw ADC Value: %d\n", raw_value);
        printf("Temperature: %.2f °C\n", temperature);
        printf("Humidity: %.2f %%\n", humidity);

        // Sleep for 10 seconds before reading again
        sleep(10);
    }

    return 0;
}
